
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128 // OLED display width, in pixels
#define SCREEN_HEIGHT 64 // OLED display height, in pixels

// Declaration for SSD1306 display connected using software SPI (default case):

Adafruit_SSD1306 oled(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

#define S1 13
#define S2 33
#define S3 14
#define S4 27
#define S5 26

int vote1 = 0;
int vote2 = 0;
int vote3 = 0;
int vote4 = 0;

int buttonState = 0;

void setup()
{

  Serial.begin(9600);

  
















   if (!oled.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println(F("SSD1306 allocation failed"));
    for (;;);
  };

  delay(2000);         // wait two seconds for initializing
  oled.clearDisplay(); // clear display

  oled.setTextSize(1);         // set text size
  oled.setTextColor(WHITE);    // set text color
  oled.setCursor(2, 5);       // set position to display
  oled.println("Voting Machine"); // set text
  oled.display();              // display on OLED

  delay(2000);

  oled.clearDisplay();

}



void loop()
{
  














  


  

}